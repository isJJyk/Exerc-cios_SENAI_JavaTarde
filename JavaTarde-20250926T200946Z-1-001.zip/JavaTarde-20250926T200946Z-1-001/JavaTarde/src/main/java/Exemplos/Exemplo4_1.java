package Exemplos;

public class Exemplo4_1
{
    public static void main(String[] args) {
        int a,b;
        double resultado;
        a=5;
        b=2;
        resultado = a/b;
        System.out.println(resultado
        );

    }
}
