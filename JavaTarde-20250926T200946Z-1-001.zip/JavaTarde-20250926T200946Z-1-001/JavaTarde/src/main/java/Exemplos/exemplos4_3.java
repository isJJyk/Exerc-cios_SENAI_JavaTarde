package Exemplos;

public class exemplos4_3 {
    public static void main(String[] args) {
        int a , b;
        double resultado;
        a = 5;
        b = 2;
        resultado = (double)a / b;
        System.out.println(resultado);

    }
}
