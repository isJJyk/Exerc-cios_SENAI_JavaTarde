package Exemplos;

public class exemplos4_2 {
    public static void main(String[] args) {
        int a, b;
        double resultado;
        a=5;
        b=2;
        resultado = a/b;
        System.out.println(resultado);

    }
}
