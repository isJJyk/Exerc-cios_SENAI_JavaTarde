package Exemplos;

public class concatenar {
    public static void main(String[] args) {
        int x =5;
        int y = 10;
        int z = x+y;
        int h = y/5;
        System.out.println("o valor de saldo disponivel para voce gastar é: "+ h );

    }
}
